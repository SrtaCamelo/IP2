package negocio;

import dados.RepoCorrida;
import feijoes.Corrida;
import java.time.*;
import java.util.ArrayList;

public class GerenciadorPessoalCorridas {
	
	private static ArrayList<Corrida> repo;
	private RepoCorrida corridasExecutadas;
	
	public GerenciadorPessoalCorridas(){
		this.corridasExecutadas = RepoCorrida.getInstance();
	}
	

	public ArrayList<Corrida> getRepo() {
		return repo;
	}

	public void setRepo(ArrayList<Corrida> repo) {
		this.repo = repo;
	}
	
	public boolean checarComecar(){
		
		boolean check = false;
		if(this.repo != null){
			
			if(this.repo.get(0).getInicio() == null){
				
				check = true;
			}
			else if(this.repo.get(0).getInicio() != null
					&& this.repo.get(0).getFim() == null){
				
				check = true;
			}	
			
		}
		else{
			check = true;
		}
		return check;
	}
	
	
	public void comecarACorrer(Corrida novaCorrida){
		
		if(checarComecar()){
	
			LocalDate inicio = null;
			novaCorrida.setInicio(inicio.now());
			this.repo.add(novaCorrida);
		}
			
	}
	public boolean checarParar(){
		
	boolean check = false;
	if(this.repo != null){
			
			if(this.repo.get(0).getInicio() != null){
				
				if(this.repo.get(0).getFim() == null){
					
					check = true;
				}										
			}
		}
	return check;
	}
	
	
	public void pararDeCorrer(){
		
		if(checarParar()){
			
			LocalDate fim = null;
			this.repo.get(0).setFim(fim.now());
			this.corridasExecutadas.cadastrar(this.repo.get(0));
			this.repo.remove(this.repo.get(0));
		}
	}
	
	public String listaCorridasExecutadas(){
		
		String menino = "Lista de Corridas Executadas:\n";
		
		for(int i = 0; i< this.corridasExecutadas.getSize(); i++)
		 menino += this.corridasExecutadas.getLrcorrida().get(i).toString()+".\n";

		return menino;
	}

	
	public String toString() {
		return "GerenciadorPessoalCorridas [corridasExecutadas=" + corridasExecutadas + "]";
	}
	
	
	
	

}
