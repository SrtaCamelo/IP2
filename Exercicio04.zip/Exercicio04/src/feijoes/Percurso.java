package feijoes;

public class Percurso {

	private String identificador;
	private String URL;
	
	public Percurso(String identificador, String uRL) {
		
		this.identificador = identificador;
		URL = uRL;
	}
	public String getIdentificador() {
		return identificador;
	}
	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}
	public String getURL() {
		return URL;
	}
	public void setURL(String uRL) {
		URL = uRL;
	}
	
	public String toString() {
		return "Percurso [identificador do Percurso=" + identificador + ", URL=" + URL + "]";
	}
	
	
	
}
