package feijoes;
import java.time.*;

public class Corrida {

	private String identificador;
	private String descricao;
	private LocalDate inicio;
	private LocalDate fim;
	private Double distancia;
	private Double velox;
	private Percurso per;
	
	public Corrida(String identificador, String descricao, Double distancia, Double velox, Percurso per) {

		this.identificador = identificador;
		this.descricao = descricao;
		this.inicio = null;
		this.fim = null;
		this.distancia = distancia;
		this.velox = velox;
		this.per = per;
	}
	
	
	public String getIdentificador() {
		return identificador;
	}

	public void setIdentificador(String identificador) {
		this.identificador = identificador;
	}

	public String getDescricao() {
		return descricao;
	}

	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}

	public LocalDate getInicio() {
		return inicio;
	}

	public void setInicio(LocalDate inicio) {
		this.inicio = inicio;
	}

	
	public String toString() {
		return "Corrida [identificador=" + identificador + ", descricao=" + descricao + ", Data de inicio=" + inicio + ", Data do fim="
				+ fim + ", distancia=" + distancia + ", velocidade=" + velox + ", percurso=" + per.toString() + "]";
	}


	public LocalDate getFim() {
		return fim;
	}

	public void setFim(LocalDate fim) {
		this.fim = fim;
	}

	public Double getDistancia() {
		return distancia;
	}

	public void setDistancia(Double distancia) {
		this.distancia = distancia;
	}

	public Double getVelox() {
		return velox;
	}

	public void setVelox(Double velox) {
		this.velox = velox;
	}

	public Percurso getPer() {
		return per;
	}

	public void setPer(Percurso per) {
		this.per = per;
	}

    public Double veloxToPace(){
		
		return (60/this.velox);
	}
    
 
}
