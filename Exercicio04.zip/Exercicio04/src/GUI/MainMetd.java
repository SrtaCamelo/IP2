package GUI;
import dados.*;
import feijoes.*;
import negocio.*;

import java.time.LocalDate;
import java.util.*;

import javax.swing.text.ChangedCharSetException;

public class MainMetd {
	public static void main(String[] args) {

		GerenciadorPessoalCorridas gerenciar = new GerenciadorPessoalCorridas();
		Scanner sc = new Scanner(System.in);
		boolean state = true;

		do{
			
			System.out.println("Bem-vindo!!\n O que deseja fazer:\n1-Iniciar uma corrida.\n2-Terminar uma "
					+ "Corrida\n3-Ver a lista de Corridas ja realizadas.");
			int option = sc.nextInt();
			switch(option){
				
			case 1: {
				
				if(gerenciar.checarComecar()){
					
					String identificador;
					String descricao;
				    LocalDate inicio;
					LocalDate fim;
					Double distancia;
					Double velox;
				    String identificadorP;//percurso
					String URL;   //percurso
					
					
					System.out.println("Digite o nome do identificador");
					identificador = sc.nextLine();
					System.out.println("Digite uma descri��o para sua corrida");
					descricao = sc.nextLine();
					System.out.println("Digite a distancia a ser percorrida");
					distancia = sc.nextDouble();
					System.out.println("Digite a velocidade corrida");
					velox = sc.nextDouble();
					System.out.println("Digite o identificador do percurso");
					identificadorP = sc.nextLine();
					System.out.println("Digite a URL do percurso");
					URL = sc.nextLine();
					
					
					Percurso p = new Percurso(identificadorP, URL);
					Corrida c = new Corrida(identificador,descricao,distancia,velox, p);
					gerenciar.comecarACorrer(c);
				}
				else{
					System.out.println("Infelizmente nao foi possivel comecar a corrida,"
							+ " pois ja existe uma em andamento");
				}
			    
				
			}
			
			case 2:{
				
				if(gerenciar.checarParar()){
					gerenciar.pararDeCorrer();
				}
				else{
					System.out.println("Nao foi possivel terminar a corrida"
							+"pois nao ha corridas em andamento");
				}
			}
			
			case 3:{
				
				System.out.println(gerenciar.listaCorridasExecutadas());
			}
								
			}
			
			System.out.println("Deseja realizar mais alguma atividade? Y/N");
			if(sc.nextLine() == "N" || sc.nextLine() == "n"){
				state = false;
				System.out.println("Obrigado por utilizar nosso servico!!");
			}
			


		}while(state);

	}
}

