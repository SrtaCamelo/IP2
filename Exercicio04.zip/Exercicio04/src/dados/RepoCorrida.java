package dados;
import java.util.ArrayList;
import feijoes.Corrida;

public class RepoCorrida {

	private ArrayList<Corrida> lrcorrida;
	private static RepoCorrida rep;
	
	private RepoCorrida(){
		lrcorrida = new ArrayList<>();
	}
	
	public static synchronized RepoCorrida getInstance(){
		if (rep == null) {
			rep = new RepoCorrida();
		}
		return rep;
	}

	public ArrayList<Corrida> getLrcorrida() {
		return lrcorrida;
	}
	public void setLrcorrida(ArrayList<Corrida> lrcorrida) {
		this.lrcorrida = lrcorrida;
	}
	public RepoCorrida(ArrayList<Corrida> lrcorrida) {
		
		this.lrcorrida = lrcorrida;
	}
	
	public void cadastrar(Corrida corrida){
		
		this.lrcorrida.add(corrida);
	}
	
	public void remover(Corrida corrida){
		
		this.lrcorrida.remove(corrida);
	}
	
	public int getSize(){
		
		return this.lrcorrida.size();
	}
	
	public Corrida recuperar(String iden){
		
		for(int i = 0; i< this.lrcorrida.size();i++){
			
			if(this.lrcorrida.get(i).getIdentificador() == iden){
				
				return this.lrcorrida.get(i);
			}
		}
		return null;
	}
	
	public boolean recuperarExists(String iden){
		
		for(int i = 0; i< this.lrcorrida.size();i++){
			
			if(this.lrcorrida.get(i).getIdentificador() == iden){
				return true;
			}

		}
	 return false;
	}
	
	
	
}
