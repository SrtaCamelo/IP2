
public class Porta {
	
	private boolean aberta;
	private String cor;
	private float dimensaoX;
	private float dimensaoY;
	private float dimensaoZ;
	
	public Porta(boolean ab, String newcor, float dX, float dY, float dZ)
	{
		aberta = ab;
		cor = newcor;
		dimensaoX = dX;
		dimensaoY = dY;
		dimensaoZ = dZ;
	}
	
	public void abre(){
		
		aberta = true;
	}
	
	public void fecha(){
		
		aberta = false;
	}
	public void pinta(String newcor){
		
		cor = newcor;
	}
	public boolean estaAberta(){
		return aberta;
	}
	public void changeDim(int dX, int dY, int dZ){ //Isso equivale ao set?
		
		dimensaoX = dX;
		dimensaoY = dY;
		dimensaoZ = dZ;
	}
	public float getDx(){
		return dimensaoX;
	}
	
	public float getDy(){
		return dimensaoY;
	}
	
	public float getDz(){
		return dimensaoZ;
	}
	public String getCor(){
		return cor;
	}
	
	
	
	public static void main(String[] args) {
		
		Porta a = new Porta(false,"amarela",2,3,4);
		a.abre();
		a.fecha();
		boolean b = a.estaAberta();
		if (b == true){
			System.out.println("Esta aberta\n");
		}
		else{
			System.out.println("Esta Fechada\n");
		}
		a.changeDim(5,6,7);
		a.pinta("Azul");
		System.out.println(a.getDx());
		System.out.println(a.getDy());
		System.out.println(a.getDz());
		System.out.println(a.getCor());
		
		
		
		
	}
	

}
