public class Casa {
	private String cor;
	private boolean p1;
	private boolean p2;
	private boolean p3;
	
	public Casa(String newcor, boolean np1,boolean np2,boolean np3){
		
		cor = newcor;
		p1 = np1;
		p2 = np2;
		p3 = np3;
	}
	public void pinta(String s)
	{
		cor = s;
	}
	public int quantasPortasEstaoAbertas()
	{
		int n = 0;
		if(p1 == true)
			n++;
		if(p2 == true)
			n++;
		if(p3 == true)
			n++;
			
		return n;
		
	}
	public void abrir(String p)
	{
		if(p == "p1")
			p1 = true;
		else if(p == "p2")
			p2 =true;
		else
			p3 = true;
			
	}
	
	public void fechar(String p)
	{
		if(p == "p1")
			p1 = false;
		else if(p == "p2")
			p2 = false;
		else
			p3 = false;
			
	}
	public String getCor(){
		return cor;
	}

	public static void main(String[] args) {
		
		Casa a = new Casa("amarela",true,true,true);
		a.pinta("Roxo");
		a.pinta("Vermelho");
		a.fechar("p1");
		a.fechar("p2");
		a.fechar("p3");
		a.abrir("p1");
		a.abrir("p2");
		
		System.out.println(a.getCor());
		System.out.println(a.quantasPortasEstaoAbertas());
		

	}

}

