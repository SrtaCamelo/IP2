
public class Livro {
	
	private Autor pessoa;
	private String title;
	private double price; 
	private int quan;
	
	public Livro(Autor newname, String newtitle, double newprice,int nquan){
		pessoa = newname;
		title = newtitle;
		price = newprice;
		quan = nquan;
	}
	
	public Autor getPessoa(){
		return pessoa;
	}
	
	public String getTitle(){
		return title;
	}
	
	public double getPrice(){
		return price;
	}
	
	public int getQuan(){
		return quan;
	}
	
	public void setPrice(double nprice){
		price = nprice;
	}
	
	public void setQuan(int nquan){
		quan = nquan;
	}
	
	public String toString(){
		
		return "Autor: " + getPessoa() + ", T�tulo: " + title + ", Pre�o: " +price + ", Quantidade: " + quan;
	}
	

}
