import java.util.Scanner;

public class MainMtd {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		String aux_name;
		String aux_gen; //Tive que mudar pra String
		String aux_mail;
		double aux_price;
		int aux_quan;
		
		System.out.println("Digite o nome do Autor: ");
		aux_name = scan.toString();
		scan.nextLine();
		System.out.println("Digite o genero do Autor: ");
		aux_gen = scan.next();
		scan.nextLine();
		System.out.println("Digite o email do Autor: ");
		aux_mail = scan.toString();
		scan.nextLine();
		
		Autor autor1 = new Autor (aux_name,aux_gen,aux_mail);
		
		System.out.println("Digite o nome do Autor: ");
		aux_name = scan.toString();
		scan.nextLine();
		System.out.println("Digite o genero do Autor: ");
		aux_gen = scan.next();
		scan.nextLine();
		System.out.println("Digite o email do Autor: ");
		aux_mail = scan.toString();
		scan.nextLine();
		
		Autor autor2 = new Autor (aux_name,aux_gen,aux_mail);
		
		System.out.println("Digite o nome do Livro: ");
		aux_name = scan.toString();
		scan.nextLine();
		System.out.println("Digite o pre�o do livro: ");
		aux_price = scan.nextDouble();
		scan.nextLine();
		System.out.println("Digite a quntidade de livros em estoque: ");
		aux_quan = scan.nextInt();
		scan.nextLine();
		
		Livro livro1 = new Livro (autor1,aux_name,aux_price,aux_quan);
		
		System.out.println("Digite o nome do Livro: ");
		aux_name = scan.toString();
		scan.nextLine();
		System.out.println("Digite o pre�o do livro: ");
		aux_price = scan.nextDouble();
		scan.nextLine();
		System.out.println("Digite a quntidade de livros em estoque: ");
		aux_quan = scan.nextInt();
		scan.nextLine();
		
		Livro livro2 = new Livro (autor2,aux_name,aux_price,aux_quan);
		
		String aux = livro1.toString();
		System.out.println(aux);
		aux = livro2.toString();
		System.out.println(aux); 
		

	}

}
