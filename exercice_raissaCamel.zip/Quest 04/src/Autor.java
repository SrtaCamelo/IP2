
public class Autor {
	
	private String nome;
	private String genero;
	private String email;
	
	public Autor(String newname, String newgen, String newemail)
	{
		nome = newname;
		genero = newgen;
		email = newemail;
	}
	
	public String getNome()
	{
		return nome;
	}
	
	public String getEmail()
	{
		return email;
	}
	
	public String getGen()
	{
		return genero;
	}
	
	public void setEmail(String newmail){
		
		email = newmail;
	}
	
	
	
}
