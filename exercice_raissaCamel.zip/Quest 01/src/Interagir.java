public class Interagir
{
	public static void main(String[] args) {
		
		
		Pessoa a = new Pessoa("Raissa", 17);
		System.out.println(a.getIdade());
		
		a.fazerAniversario();
		System.out.println(a.getIdade());
	}
}
