public class Pessoa {
	
	private String nome;
	private int idade;
	
    public Pessoa(String newnome, int newidade){
    	
    	nome = newnome;
    	idade = newidade;
    }
    
    public String getNome(){
    	return nome;
    }
    
    public int getIdade(){
    	return idade;	
    }
    
    public void setNome(String n){
    	nome = n;
    }
    
    public void setIdade(int i){
    	idade = i;
    }
	
	public void fazerAniversario()
	{
		idade++;
	}



}

