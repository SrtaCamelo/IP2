package quest03;

import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Api {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Digite sua data de anivers�rio"); // tem que digitar ano-mes-dia
		String dateb = sc.nextLine();
		LocalDate birth = LocalDate.parse(dateb);
		LocalDate today = LocalDate.now();
		Period time = birth.until(today);
		LocalDate plus = birth.plusYears(1);
		
		System.out.println("Voc� viveu: "+time.getYears()+" anos, "+time.getMonths()+"meses, "+time.getDays()+"dias, "+time.negated());
		System.out.println("Seu primeiro aniverssario foi num(a): "+ plus.getDayOfWeek());
		System.out.println("Seu aniverssario de 18 anos ser�(foi) num(a): "+plus.plusYears(17).getDayOfWeek());
		sc.close();
		
		

		//System.out.println(birth);
	}

}
