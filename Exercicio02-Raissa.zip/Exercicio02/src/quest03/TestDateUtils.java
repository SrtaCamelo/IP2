package quest03;
import java.time.*;
import java.util.Scanner;
public class TestDateUtils {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Digite a primeira data: "); //ano-mes-dia
		String aux = sc.nextLine();
		LocalDate day1 = LocalDate.parse(aux);
		System.out.println("Digite a segunta data: ");
		aux = sc.nextLine();
		LocalDate day2 = LocalDate.parse(aux);
		sc.close();
		DateUtils dif = new DateUtils(day1,day2);
		System.out.println(dif.diasUteis());
		

	}

}
