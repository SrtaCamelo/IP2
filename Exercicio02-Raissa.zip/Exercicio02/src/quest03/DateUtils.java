package quest03;
import java.time.LocalDate;
import java.time.Period;


public class DateUtils {
	
	private LocalDate day1;
	private LocalDate day2;
	
	public DateUtils(LocalDate day1, LocalDate day2){
		
		this.day1 = day1;
		this.day2 = day2;
		
	}
	
	public int diasUteis(){
		 
		
		Period time = this.day1.until(this.day2);
		int n = time.getDays();
		int cont=0;
		int indicator = this.day1.getDayOfWeek().getValue();
		
		for(int i=1; i<n; i++){
			
			
			if(indicator != 6 || indicator != 7){
				
				cont++;
			}
			if(indicator < 7){
				
				indicator ++;

			}
			if (indicator == 7){
				
				indicator = 1;
			}
			
		}
		return cont;
	}
	

}
