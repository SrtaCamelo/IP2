package quest01;

public class MainMtd {

	public static void main(String[] args) {
		
		Padrao p = new Padrao();
		p.padrao01();
		p.padrao02();
		p.padrao03();
		p.padrao04();
		
	}

}
