package quest01;

public class Padrao {
	
	int i;
	
	public void padrao01(){
		
		int i,j;

		   System.out.println("Padrao 01");
		   for (i=1; i<11; i++)
		    {
		        for (j=0; j<i; j++)
		        {
		           System.out.print("*");
		        }
		        System.out.print("\n");
		    }
	}
	
	public void padrao02(){
		
		int i,j;
		System.out.println("Padrao 02");
		for (i=0; i<11; i++)
	    {
	        for (j=10; j>i; j--)
	        {
	            System.out.print("*");;
	        }
	        System.out.println();
	    }
	}
	
	public void padrao03(){
		
		int i,j,z;
		 System.out.println("Padrao 03");
		    for (i=1;i<11; i++)
		    {
		        for (j=1; j<i; j++)
		        {
		           System.out.print(" ");
		        }
		        for (z=11; z>i; z--)
		        {
		            System.out.print("*");
		        }
		        System.out.println();
		    }
	}
	
	public void padrao04(){
		
		int i,j,z;
		System.out.println("Padrao 04");
	    for (i=1;i<11; i++)
	    {
	        for (z=10; z>i; z--)
	        {
	            System.out.print(" ");

	        }
	        for (j=0; j<i; j++)
	        {
	           System.out.print("*");
	        }
	        System.out.println();
	    }
		
	}

}
