package quest02;

public class MyTriangle {
	
	private MyPoint v1;
	private MyPoint v2;
	private MyPoint v3;
	
	public MyTriangle (int x1,int y1,int x2,int y2, int x3,int y3){
		
		MyPoint p = new MyPoint(x1,y1);
		this.v1 = p;
		p = new MyPoint(x2,y2);
		this.v2 = p;
		p = new MyPoint(x3,y3);
		this.v3 = p;
	}
	
	public MyTriangle(MyPoint v1,MyPoint v2,MyPoint v3){
		
		this.v1 = v1;
		this.v2 = v2;
		this.v3 = v3;
		
	}
	public void setTriangle(MyPoint v1,MyPoint v2,MyPoint v3){
		
		this.v1=v1;
		this.v2=v2;
		this.v3=v3;
	}
	
	public void setTriangle(int x1,int y1,int x2,int y2, int x3,int y3){
		
		this.v1.setX(x1);
		this.v2.setX(x2);
		this.v3.setX(x3);
		this.v1.setY(y1);
		this.v2.setY(y2);
		this.v3.setY(y3);
	}
	
	
	
	public String triangleTYPE(){
		
		String result;
		double v1V2 = this.v1.distance(this.v2);
		double v2V3 = this.v2.distance(this.v3);
		double v3V1 = this.v3.distance(this.v1);
		
		if((v1V2 == v2V3) && (v2V3 == v3V1)){
			
			result = "Equilatero";
		}
		else if((v1V2 != v2V3) && (v2V3 == v3V1)){
			
			result = "Isosceles";
		}
		else if((v3V1 != v1V2) && (v1V2 == v2V3)){
			
			result = "Isosceles";
		}
		else if((v2V3 != v1V2) && (v1V2 == v3V1)){
			result = "Isosceles";
		}
		else{
			result = "Escaleno";
		}
		
		return result;
	}
	
	public String toString(){
		
		return "MyTriangle  " + this.triangleTYPE() + "  @  " + this.v1.toString()+"," + this.v2.toString()+"," + this.v3.toString();	
		
	}
	
	public boolean equals(MyTriangle t1){
		
		return ((this.v1.equals(t1.v1)) && (this.v2.equals(t1.v2)) && (this.v3.equals(t1.v3)));
		
	}
	
	
	
}
