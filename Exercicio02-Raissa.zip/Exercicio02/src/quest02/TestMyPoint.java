package quest02;

public class TestMyPoint {

	public static void main(String[] args) {
		
		MyPoint p1 = new MyPoint();
		MyPoint p2 = new MyPoint(2,3);
		MyPoint p3 = new MyPoint(2,3);
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		
		if ( p2.equals(p3)){
			System.out.println("S�o Iguais!!");
		}
		
		else {
			System.out.println("S�o diferentes!!");
		}
		
		p3.setX(1); p3.setY(2);
		System.out.println(p3);
		
		if ( p2.equals(p3)){
			System.out.println("S�o Iguais!!");
		}
		
		else {
			System.out.println("S�o diferentes!!");
		}
		
		

	}
	
	
}
