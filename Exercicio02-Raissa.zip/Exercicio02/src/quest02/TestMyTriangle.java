package quest02;

public class TestMyTriangle {

	public static void main(String[] args) {
		
		MyTriangle t1 = new MyTriangle(1,2,3,4,5,6);
		MyTriangle t2 = new MyTriangle(new MyPoint(1,2), new MyPoint(3,4),new MyPoint(5,6));
				
		System.out.println(t1.toString());
		System.out.println(t2.toString());
		System.out.println(t1.equals(t2));
		
		t1.setTriangle(new MyPoint(12,20),new MyPoint(5,20) , new MyPoint(90,20));
		t2.setTriangle(0, 3, -2, -5, 6, -3);
		System.out.println(t1.toString());
		System.out.println(t2.toString());
		System.out.println(t1.equals(t2));
		
		
	}

}
