package quest02;

public class TestMyCircle {

	public static void main(String[] args) {
		
		MyCircle c1 = new MyCircle(2,3,1);
		MyCircle c2 = new MyCircle(new MyPoint(2,3),1);
		MyCircle c3 = new MyCircle(new MyPoint(2,3),1);
		
		System.out.println(c1.getCenterX());
		System.out.println(c1.getCenterY());
		System.out.println(c1.getRadius());
		
		System.out.println(c2.getCenter());
		System.out.println("Radius:"+c2.getRadius());
		System.out.println(c2.getArea());
		
		System.out.println(c3.getCenter());
		System.out.println("Radius:"+c3.getRadius());
		System.out.println(c3.getArea());
		
		c2.testEquals(c2.equals(c3));
	
		
		c2.setCenter(new MyPoint(1,3));
		c2.setRadius(4);
		c3.setCenterXY(3, 5);
		c3.setRadius(2);
		
		System.out.println(c2.getCenter());
		System.out.println("Radius:"+c2.getRadius());
		System.out.println(c2.getArea());
		
		System.out.println(c3.getCenter());
		System.out.println("Radius:"+c3.getRadius());
		System.out.println(c3.getArea());
		
		c2.testEquals(c2.equals(c3));
	}

}
