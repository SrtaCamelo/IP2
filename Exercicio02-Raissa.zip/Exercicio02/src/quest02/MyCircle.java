package quest02;

public class MyCircle {
	
	private MyPoint center;
	private int radius = 1;
	
	public MyCircle(int x,int y, int radius){
		
		this.radius = radius;
		MyPoint aux = new MyPoint(x,y);
		this.center = aux;
		
	}
	public MyCircle(MyPoint center, int radius){
		
		this.center = center;
		this.radius = radius;
	}
	
	public int getRadius(){
		
		return this.radius;
		
	}
	
	public void setRadius(int radius){
		
		this.radius = radius;
	}
	public MyPoint getCenter(){
		
		return this.center;
	}
	public void setCenter(MyPoint center){
		
		this.center = center;
	}
	
	public int getCenterX(){
		
		return this.center.getX();
	}
	
	public int getCenterY(){
		
		return this.center.getY();
	}
	
	public void setCenterXY(int x, int y){
		
	    this.center.setX(x);
	    this.center.setY(y);
	}
	
	public String toString(){
		
		return "Circle @" + this.center.toString() + "radius = "+radius+"; area ="+ getArea();
	}
	
	public double getArea(){
		
		return (3.14* Math.pow(this.radius,2));
	}
	
	public boolean equals(MyCircle circle){
		
		boolean test = ( this.center.equals(circle.getCenter()) && (this.radius == circle.getRadius())     );
		return test;
			
	}
	
	public void testEquals(boolean test){
		if(test){
			
			System.out.println("S�o iguais!\n\n");
		}
		else{
			System.out.println("S�o diferentes!");
		}
	}
	
	
	
	
	
	


}
