package quest01;
import java.util.Random;
import java.util.Arrays;

public class BilheteDeLoteria {
	
	private int[] array; 
	
	public  BilheteDeLoteria(int n){
		
		this.array = new int[n];
		boolean buscar = false;
		
		for(int i = 0; i<n;i++){
		  while(!buscar){
			  
			array[i] = new Random().nextInt(60)+1;
			if(i > 0){
				buscar = buscarArray(i,array[i]);
			}
			
			
		  }
		}
			java.util.Arrays.sort(this.array);	
			

		}
	
	
	private boolean buscarArray(int n,int elemento){
		
		for(int i = 0; i<n;i++){
			
			if(elemento == this.array[i]){
				return false;
			}
			
		}
		return true;	
	}
	
	public String toString(){
		
		String result = "[";
		for(int i = 0; i< this.array.length;i++){
			
			result += this.array[i] + ",";
		}
		result += "]";
		return result;
	}

	public boolean contem(BilheteDeLoteria bilhete){

		int n = bilhete.array.length;
		int n1 = this.array.length;
		int check = 0;

		for(int i = 0;i<n1;i++){

			for(int j = 0;j<n;j++){

				if(bilhete.array[j]== this.array[i]){
					check++;
				}	
			}
		}

		if(check == n){

			return true;
		}
		return false;

	}
	
	
	
	

}



