package quest01;

public class TesteBilhete {

	public static void main(String[] args) {

			BilheteDeLoteria[] arrayBilhete = new BilheteDeLoteria[10];
			for(int i =0;i<10;i++){
				int n = 6;

				arrayBilhete[i] = new BilheteDeLoteria(n);

				if(n < 11){
					n++;
				}
			}

		int cont = 0;
		boolean megaWin = false;
		while(!megaWin){

			cont+=;
			System.out.println("Sorteio de número: "+cont+"!!");
			BilheteDeLoteria premiado = new BilheteDeLoteria(6);



			for(int i =0; i<10;i++){

				System.out.println("Testando se o bilhete cujos números são:"+ arrayBilhete[i].toString()+
					"contém todos os números do bilhete"+premiado.toString());

				if(arrayBilhete[i].contem(premiado)){
					megaWin = true;
					System.out.println("Parabéns, você ganhou na MegaSena!!");
				}
			}
		}
	}



}
