package quest02;

import java.util.ArrayList;
import java.util.Random;

public class MainMtd(){

	public static void main(String[] args){

		ArrayList<Integer> arrayli = new ArrayList<Integer>();
		arrayli.add(Random().nextInt(60));
		arrayli.add(Random().nextInt(60));
		arrayli.add(Random().nextInt(60));
		arrayli.add(Random().nextInt(60));
		arrayli.add(Random().nextInt(60));
		arrayli.add(Random().nextInt(60));
		arrayli.add(Random().nextInt(60));
		arrayli.add(Random().nextInt(60));
	}

}