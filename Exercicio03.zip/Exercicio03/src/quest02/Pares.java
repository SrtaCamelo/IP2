package quest02;
import java.util.ArrayList;

public class Pares{

	//private ArrayLis<Integer> array;

	//public Pares(ArrayList<Integer> array){

		//this.array = array;
	//}

	public String removeParesRuins(ArrayList<Integer> array){

		if(array.isEmpty()){

			return array;
		}
		else{

			for(int i = 0; i < array.lengh;i++){

				if(i % 2 == 0){

					if( array[i+1] != Null){

						if(array[i] > array[i+1]){

							array.remove(i);
							array.remove(i+1);
						}

					}
					else{
						array.remove(i);
					}
				}

			}

		}



	}
}