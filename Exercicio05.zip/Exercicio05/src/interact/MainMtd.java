package interact;
import cursos.*;

public class MainMtd {
	
	private static int tamanhoDoArray = 0;
	private static Pessoa[] arrayDePessoas = new Pessoa[100];
	
    private static String generateClasse(String curso){
    	
    	String totalClass = "Curso: "+curso;
		for(int j = 0; j< tamanhoDoArray;j++){
			
			if(arrayDePessoas[j].getClass().equals("Professor")){
				Professor p = (Professor) arrayDePessoas[j];
				for(int k = 0; k< p.getNumCursos(); k++){
					
					if(p.getCurso(k).equals(curso)){
					
						totalClass += "\n Professor: "+p.getNome();
					}
				}
			}
		}
		totalClass += "\n Alunos: ";
		for(int x = 0; x< tamanhoDoArray; x++){
			if(arrayDePessoas[x].getClass().equals("Estudante")){
				Estudante e = (Estudante)arrayDePessoas[x];
				for(int v =0; v< e.getNumCursos(); v++){
					if(e.getCurso(v).equals(curso)){
						
						totalClass += "\n "+e.getNome();
					}
				}
			}
		}
		return totalClass;
	}
	
	 
	static void addAoArray(Pessoa pessoa){
		arrayDePessoas[tamanhoDoArray] = pessoa;
        tamanhoDoArray++;
	}
	
	public static void main(String args) {
		
		Estudante estudante1 = new Estudante("Raissa","lab 42/33"); //Pessoa?
		Estudante estudante2 = new Estudante("Carlos Magno","lab 33");
		
		estudante1.addCursoNota("Introducao a Prog II", 10);
		estudante1.addCursoNota("Introducao a Prog I", 9);
		estudante2.addCursoNota("Introducao a Prog II",9); //Sou humilde
		estudante2.addCursoNota("Matematica Discreta I",0);
		
		addAoArray(estudante1);
		addAoArray(estudante2);
		//arrayDePessoas[0] = estudante1;
		//arrayDePessoas[1] = estudante2;
		
		Professor professor1 = new Professor("Leandro","Rural");
		Professor professor2 = new Professor("Filipe","Rural");
		professor1.addCurso("Introducao a Prog II");
		professor2.addCurso("Matematica Discreta I");
		
		addAoArray(professor1);
		addAoArray(professor2);
		//arrayDePessoas[2] = professor1;
		//arrayDePessoas[3] = professor2;
		//tamanhoDoArray = 4;
		
		for(int i = 0; i< tamanhoDoArray; i++){
			
			System.out.println(arrayDePessoas[i]);
		}
		System.out.println(generateClasse("Introducao a Prog II"));
		System.out.println(generateClasse("Matematica Discreta I"));
		
		
		
		
	}

}
