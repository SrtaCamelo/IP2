package cursos;


public class Pessoa {
	
	private String nome;
	private String endereco;
	
	public Pessoa(String nome, String endereco){
		
		this.nome = nome;
		this.endereco = endereco;
		
		
	}
	
	public String getNome(){
		return this.nome;
	}
	
	public String getEndereco(){
		return this.endereco;
	}
	
	public String toString(){
		
		return "Pessoa :"+this.nome+ "\n Endereco: "+this.endereco;
	}

}