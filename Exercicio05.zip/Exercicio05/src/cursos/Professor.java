package cursos;

public class Professor extends Pessoa {

	private int numCursos;
	private String[] cursos;
	
	public Professor(String nome, String endereco){
		
		super(nome,endereco);
		this.cursos = new String[100];
		this.numCursos = 0;
	}
	public int getNumCursos(){
		return this.numCursos;
	}
	
	public String getCurso(int indice){
		return this.cursos[indice];
	}
	public String toString(){
		
		String aux = "Nome: Professor "+super.getNome()+". Endereco: "+super.getEndereco()+". Cursos que leciona: ";
		
		for(int i = 0; i<numCursos; i++){
			
			aux += "Disciplina: "+this.cursos[i];
		}
		
		return aux;
		
	}
	
	public boolean addCurso(String curso){
		
		boolean check = true;
		for(int j =0;j<this.numCursos;j++){
			
			if(this.cursos[j].equals(curso)){
				
				check = false;
			}
		}
		if(check){
			
			this.cursos[numCursos] = curso;
			this.numCursos++;
		}
	 return check;

	}
	
	public boolean removeCurso(String curso){
		
		boolean check = false;
		for(int j =0;j<this.numCursos;j++){
			
			if(this.cursos[j].equals(curso)){
				
				check = true;
				this.cursos[j] = this.cursos[numCursos - 1];
				this.cursos[numCursos - 1] = null;
				this.numCursos--;
			}
		}
	
	 return check;

	}
	
}
