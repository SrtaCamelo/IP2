package cursos;

public class Estudante extends Pessoa {
	
	
	private int numCursos;
	private String[] cursos;
	private int[] notas;
	
	public Estudante(String nome, String endereco){
		
		super(nome, endereco);
		this.cursos = new String[100];
		this.notas = new int[100];
		this.numCursos = 0;
	}
	public int getNumCursos(){
		return this.numCursos;
	}
	public String getCurso(int indice){
		return this.cursos[indice];
	}
	
	public String toString(){
		
	  String aux = super.toString()+"\n"+"Numero de cursos:"+this.numCursos;
	  
	  for(int i = 0; i< numCursos;i++){
		  
		  aux += "\n"+" Curso: "+this.cursos[i]+" Nota: "+this.notas[i];
	  }
	  
	  return aux;
	}
	
	public boolean addCursoNota(String curso, int nota){
		
		boolean check = true;
		for(int j =0;j<this.numCursos;j++){
			
			if(this.cursos[j].equals(curso)){
				
				check = false;
			}
		}
		if(check){
			
			this.cursos[numCursos] = curso;
			this.notas[numCursos] = nota;
			this.numCursos++;
		}
	 return check;
	
	}
	
	public void imprimeNotas(){
		
		for(int i = 0;i< numCursos;i++){
			
			System.out.println("Curso: "+this.cursos[i]+"  Nota: "+this.notas[i]);
		}
	}
	
	public double getNotaMedia(){
		
		double media = 0;
		for(int i = 0; i< numCursos; i++){
			
			media += this.notas[i];
		}
		media = media/numCursos;
		return media;
	}
}
